<h3 class="accordion_tab" id="<?php esc_attr_e($id) ?>"><a href="#"><?php esc_html_e($title) ?></a></h3>
<div id="<?php esc_attr_e($id) ?>_content">
	<?php echo $content ?>
</div>